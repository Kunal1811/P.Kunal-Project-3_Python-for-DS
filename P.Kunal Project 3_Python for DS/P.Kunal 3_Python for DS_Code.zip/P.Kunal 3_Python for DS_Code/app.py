from flask import Flask
from flask import render_template,url_for,request,redirect,session
import base64
import pickle
import numpy as np
from numpy import asarray
from sklearn.preprocessing import OrdinalEncoder
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# loading the trained model 
model=pickle.load(open('model.pkl','rb'))

app.config['DEBUG'] = True
app.config['ENV'] = 'development'
app.config['FLASK_ENV'] = 'development'
app.config['SECRET_KEY'] = 'ItShouldBeALongStringOfRandomCharacters'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:admin@localhost:3306/house_loan'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class accounts(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50))
    password = db.Column(db.String(255))

   
with app.app_context():
    db.create_all()

# http://127.0.0.1:5000/home - this will be the home page.
@app.route('/home')
def home():
        return render_template('home.html')

# http://127.0.0.1:5000/register - this will be registration page
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template("register.html")

    elif request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        valid_user = \
            accounts.query.filter(accounts.username == request.form.get('username')).count()
        if valid_user:
            return f"<h2> User already registered !! Please go to HOME page to login.</h2>"
        else:
            new_user = accounts(username=request.form.get('username'),password=base64.b64encode(request.form.get('password').encode("utf-8")))            
            db.session.add(new_user)
            db.session.commit()
            return render_template('home.html',registered_text="Registered successfully !! Please login to check loan eligibility.") # f"<h2> Registered successfully !! Please go to HOME page to login. </h2>"
        strn = url_for("register")
    else:
        return f"<h1>Please fill out the form!</h1>"

# http://127.0.0.1:5000/login -- This will be login page
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template("login.html")

    elif request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        valid_user = \
            accounts.query.filter(accounts.username == request.form.get('username')).count()
        valid_password = \
            accounts.query.filter(accounts.password == base64.b64encode(request.form.get('password').encode("utf-8"))).count()
        if valid_user and valid_password:
            return render_template('predict.html') 
        else:
            return f"<h2> Incorrect username/password!</h2>"

# http://127.0.0.1:5000/enterdetails -- This will be form page
@app.route('/enterdetails',methods=['POST']) 
def enterdetails():
    if request.method == 'POST':
        X=request.form['gender']
        Gen = np.reshape(X, (1, -1))
        Gen1 = OrdinalEncoder().fit_transform(Gen)
        Gen1 = float(Gen1)
        Gender = Gen1

        W =request.form['married']
        Marri = np.reshape(W, (1, -1))
        Marri1 = OrdinalEncoder().fit_transform(Marri)
        Marri1 = float(Marri1)
        Married = Marri1

        Dependents=float(request.form['dependents'])

        V = request.form['education']
        Edu = np.reshape(V, (1, -1))
        Edu1 = OrdinalEncoder().fit_transform(Edu)
        Edu1 = float(Edu1)
        Education = Edu1

        Y = request.form['selfemp']
        Self = np.reshape(Y,(1,-1))
        Self1 = OrdinalEncoder().fit_transform(Self)
        Self1 = float(Self1)
        SelfEmployed = Self1

        Applicant_Income=float(request.form['applicantincome'])
        Co_Applicant_Income=float(request.form['coapplicantincome'])
        Loan_Amt=float(request.form['loanamt'])
        Loan_Amt_Term=int(request.form['loanamtterm'])
        
        Z = request.form['crhist']
        CredHis = np.reshape(Z,(1,-1))
        CredHis1 = OrdinalEncoder().fit_transform(CredHis)
        CredHis1 = float(CredHis1)
        Credit_Hist = CredHis1

        U = request.form['proparea']
        Parea = np.reshape(U,(1,-1))
        Parea1 = OrdinalEncoder().fit_transform(Parea)
        Parea1 = float(Parea1)
        Prop_area = Parea1
 
        prediction=model.predict([np.array([Gender,Married,Dependents,Education,SelfEmployed,Applicant_Income,Co_Applicant_Income,Loan_Amt,Loan_Amt_Term,Credit_Hist,Prop_area])])
        output=round(prediction[0],2)       
        return render_template('predict.html')
    
# http://127.0.0.1:5000/predict -- This will be result page (Though this is duplicate API ; since it was given in assignment added this API.)
@app.route('/predict',methods=['POST']) 
def predict():
    if request.method == 'POST':
        X=request.form['gender']
        Gen = np.reshape(X, (1, -1))
        Gen1 = OrdinalEncoder().fit_transform(Gen)
        Gen1 = float(Gen1)
        Gender = Gen1

        W =request.form['married']
        Marri = np.reshape(W, (1, -1))
        Marri1 = OrdinalEncoder().fit_transform(Marri)
        Marri1 = float(Marri1)
        Married = Marri1

        Dependents=float(request.form['dependents'])

        V = request.form['education']
        Edu = np.reshape(V, (1, -1))
        Edu1 = OrdinalEncoder().fit_transform(Edu)
        Edu1 = float(Edu1)
        Education = Edu1

        Y = request.form['selfemp']
        Self = np.reshape(Y,(1,-1))
        Self1 = OrdinalEncoder().fit_transform(Self)
        Self1 = float(Self1)
        SelfEmployed = Self1

        Applicant_Income=float(request.form['applicantincome'])
        Co_Applicant_Income=float(request.form['coapplicantincome'])
        Loan_Amt=float(request.form['loanamt'])
        Loan_Amt_Term=int(request.form['loanamtterm'])
        
        Z = request.form['crhist']
        CredHis = np.reshape(Z,(1,-1))
        CredHis1 = OrdinalEncoder().fit_transform(CredHis)
        CredHis1 = float(CredHis1)
        Credit_Hist = CredHis1

        U = request.form['proparea']
        Parea = np.reshape(U,(1,-1))
        Parea1 = OrdinalEncoder().fit_transform(Parea)
        Parea1 = float(Parea1)
        Prop_area = Parea1
 
        prediction=model.predict([np.array([Gender,Married,Dependents,Education,SelfEmployed,Applicant_Income,Co_Applicant_Income,Loan_Amt,Loan_Amt_Term,Credit_Hist,Prop_area])])
        output=round(prediction[0],2)
        if output == '0':
            msg="Not eligible"
        else:
            msg="eligible"
        
        return render_template('predict.html',prediction_text="Congrats you are {} for loan".format(msg))

    
# http://http://127.0.0.1:5000/logout - this will be the logout page
@app.route('/logout')
def logout():
    # Remove session data, this will log the user out
   session.pop('loggedin', None)
   session.pop('id', None)
   session.pop('username', None)
   # Redirect to login page -- redirect(url_for('logout'))
   return render_template('logout.html')

if __name__ == "__main__":
    app.run(debug=True)

